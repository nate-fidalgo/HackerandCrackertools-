package com.example.sensortester;


import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.location.LocationManagerCompat;
import androidx.core.widget.ContentLoadingProgressBar;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class SensorTesting extends AppCompatActivity {

    private SensorManager mSensorManager;
    private StringBuffer sensbuf ;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_testing);
        mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        List<Sensor> listofsensors = mSensorManager.getSensorList (Sensor.TYPE_ALL) ;
        sensbuf = new StringBuffer() ;

        for( Sensor sensor : listofsensors)
        {
            Log.i("SENSORINFO:", sensor.getName());
            sensbuf.append( sensor.toString() ) ;
            sensbuf.append("\n\n") ;

        }

        TextView tview = new TextView(this) ;
        tview.setText(sensbuf);
        tview.setTextColor(Color.WHITE);
        tview.setBackgroundColor(Color.BLACK);

        ((LinearLayout)findViewById(R.id.layoutID)).addView(tview);

        Log.i("SENSORINFO:" , "TEMP " +  mSensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE ) ) ;
        Log.i("SENSORINFO:" , "HEART " +  mSensorManager.getDefaultSensor(Sensor.TYPE_HEART_BEAT ) ) ;
        Log.i("SENSORINFO:" , "HEART " +  mSensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE) ) ;
        Log.i("SENSORINFO:" , "PRESSURE " +  mSensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE) ) ;
       // Log.i("SENSORINFO:" , "TEMP " +  mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY) ) ;
        Log.i("SENSORINFO:" , "HUMIDITY " +  mSensorManager.getDefaultSensor(Sensor.TYPE_RELATIVE_HUMIDITY) ) ;
        Log.i("SENSORINFO:" , "POSE " +  mSensorManager.getDefaultSensor(Sensor.TYPE_POSE_6DOF) ) ;


        List<Sensor> listofsensors2 = mSensorManager.getDynamicSensorList(Sensor.TYPE_ALL) ;
        Log.i("SENSORINFO:", "-------------------------------------------------------");

        for( Sensor sensor : listofsensors2)
        {
            Log.i("SENSORINFO:", sensor.getName());
        }

        LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE );
        boolean statusOfGPS = manager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        Log.i("SENSORINFO:", "GPS = " + statusOfGPS);
        if( statusOfGPS == true )
        {
            Spannable gpstext = new SpannableString("GPS AVAILABLE!!!");

            gpstext.setSpan(new ForegroundColorSpan(Color.RED), 0, gpstext.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

            tview.append(gpstext);

        }

        Vibrator vi;

        vi = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        if(vi.hasVibrator()){
            Spannable vibtext = new SpannableString("\nPhone has vibrator capabilities!!!");

            vibtext.setSpan(new ForegroundColorSpan(Color.GREEN), 0, vibtext.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

            tview.append(vibtext);
            vi.vibrate(1000);

        }

    }

    public void exitAction(View view)
    {
      //  Context context = getApplicationContext();
      //  CharSequence text = "Android sensors say goodbye!";
      //  int duration = Toast.LENGTH_SHORT;

      //  Toast toast = Toast.makeText(context, text, duration);
      //  toast.setGravity(Gravity.TOP| Gravity.LEFT, 0, 0);
     //   toast.show();
     //   super.onDestroy();
        //this.finish();
        this.finish();
        System.exit(0);
    }

    protected void onDestroy() {


        super.onDestroy();
        Log.i( "SENSORINFO:" ,"destroying app now ") ;

    }


}